import { useState } from 'react';
import OnboardingScreen from './components/OnboardingScreen';
import LoginScreen from './components/LoginScreen';
import SignUpScreen from './components/SignUpScreen';
import HomeScreen from './components/HomeScreen';
import ReceiptScreen from './components/ReceiptScreen';
import OCRReviewScreen from './components/OCRReviewScreen';
import ExpenseScreen from './components/ExpenseScreen';
import AddExpenseScreen from './components/AddExpenseScreen';
import ReportsScreen from './components/ReportsScreen';
import InsightsScreen from './components/InsightsScreen';
import PredictionScreen from './components/PredictionScreen';
import NotificationsScreen from './components/NotificationsScreen';
import BudgetPreferencesScreen from './components/BudgetPreferencesScreen';
import ProfileScreen from './components/ProfileScreen';
import BottomNav from './components/BottomNav';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('onboarding');

  const screensWithoutNav = ['onboarding', 'login', 'signup', 'ocr-review', 'add-expense', 'reports', 'notifications', 'budget-preferences', 'predictions'];
  const showBottomNav = !screensWithoutNav.includes(currentScreen);

  const renderScreen = () => {
    switch (currentScreen) {
      case 'onboarding':
        return <OnboardingScreen onNavigate={setCurrentScreen} />;
      case 'login':
        return <LoginScreen onNavigate={setCurrentScreen} />;
      case 'signup':
        return <SignUpScreen onNavigate={setCurrentScreen} />;
      case 'home':
        return <HomeScreen onNavigate={setCurrentScreen} />;
      case 'receipts':
        return <ReceiptScreen onNavigate={setCurrentScreen} />;
      case 'ocr-review':
        return <OCRReviewScreen onNavigate={setCurrentScreen} />;
      case 'expenses':
        return <ExpenseScreen onNavigate={setCurrentScreen} />;
      case 'add-expense':
        return <AddExpenseScreen onNavigate={setCurrentScreen} />;
      case 'reports':
        return <ReportsScreen onNavigate={setCurrentScreen} />;
      case 'insights':
        return <InsightsScreen onNavigate={setCurrentScreen} />;
      case 'predictions':
        return <PredictionScreen onNavigate={setCurrentScreen} />;
      case 'notifications':
        return <NotificationsScreen onNavigate={setCurrentScreen} />;
      case 'budget-preferences':
        return <BudgetPreferencesScreen onNavigate={setCurrentScreen} />;
      case 'profile':
        return <ProfileScreen onNavigate={setCurrentScreen} />;
      default:
        return <HomeScreen onNavigate={setCurrentScreen} />;
    }
  };

  return (
    <div className="size-full relative" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="h-full max-w-md mx-auto shadow-lg" style={{ backgroundColor: '#FFFFFF' }}>
        {renderScreen()}
        {showBottomNav && (
          <BottomNav activeScreen={currentScreen} onNavigate={setCurrentScreen} />
        )}
      </div>
    </div>
  );
}