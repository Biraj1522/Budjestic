interface ReceiptScreenProps {
  onNavigate: (screen: string) => void;
}

export default function ReceiptScreen({ onNavigate }: ReceiptScreenProps) {
  const receipts = [
    { id: 1, store: 'SuperMart', amount: '$45.20', date: 'May 6, 2026', status: 'Processed', img: 'https://images.unsplash.com/photo-1634733988138-bf2c3a2a13fa?w=400' },
    { id: 2, store: 'Fresh Grocery', amount: '$89.50', date: 'May 5, 2026', status: 'Processed', img: 'https://images.unsplash.com/photo-1730367362780-a7b9f490fb15?w=400' },
    { id: 3, store: 'QuickStop Market', amount: '$32.10', date: 'May 5, 2026', status: 'Pending', img: 'https://images.unsplash.com/photo-1618069416986-eb1677ba3cc9?w=400' },
    { id: 4, store: 'Corner Store', amount: '$67.80', date: 'May 4, 2026', status: 'Processed', img: 'https://images.unsplash.com/photo-1673874855449-e8620ddfa867?w=400' },
    { id: 5, store: 'City Supermarket', amount: '$124.30', date: 'May 3, 2026', status: 'Processed', img: 'https://images.unsplash.com/photo-1579808324991-cecc784498cc?w=400' },
    { id: 6, store: 'Organic Market', amount: '$53.90', date: 'May 3, 2026', status: 'Processed', img: 'https://images.unsplash.com/photo-1648823161626-0e839927401b?w=400' },
    { id: 7, store: 'Daily Mart', amount: '$28.45', date: 'May 2, 2026', status: 'Pending', img: 'https://images.unsplash.com/photo-1623123096602-35c9aabf9407?w=400' },
    { id: 8, store: 'Food Plaza', amount: '$95.60', date: 'May 1, 2026', status: 'Processed', img: 'https://images.unsplash.com/photo-1731156673867-c80f77344015?w=400' },
    { id: 9, store: 'Express Grocery', amount: '$41.25', date: 'Apr 30, 2026', status: 'Processed', img: 'https://images.unsplash.com/photo-1594230178058-d8660e31e491?w=400' },
    { id: 10, store: 'Value Store', amount: '$76.15', date: 'Apr 29, 2026', status: 'Processed', img: 'https://images.unsplash.com/photo-1579808352667-5db8c02598ce?w=400' },
  ];

  return (
    <div className="h-full overflow-y-auto pb-20" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-6" style={{ color: '#0F172A' }}>Receipt Upload</h2>

        <button
          onClick={() => onNavigate('ocr-review')}
          className="w-full border-2 border-dashed rounded-xl p-12 mb-4 flex flex-col items-center justify-center"
          style={{ backgroundColor: '#FFFFFF', borderColor: '#CBD5E1' }}
        >
          <div className="w-16 h-16 rounded-full flex items-center justify-center mb-3" style={{ backgroundColor: '#DBEAFE' }}>
            <span className="text-3xl">📸</span>
          </div>
          <p className="font-semibold mb-1" style={{ color: '#0F172A' }}>Scan or Upload Receipt</p>
          <p className="text-sm text-center" style={{ color: '#64748B' }}>Tap to add a new receipt</p>
        </button>

        <div className="p-3 rounded-lg mb-6" style={{ backgroundColor: '#EFF6FF' }}>
          <p className="text-xs text-center" style={{ color: '#2563EB' }}>
            OCR will extract item names, prices, date, and total amount
          </p>
        </div>

        <div className="mb-3">
          <h3 className="font-semibold" style={{ color: '#0F172A' }}>Recent Receipts</h3>
        </div>

        <div className="space-y-3">
          {receipts.map((receipt) => (
            <button
              key={receipt.id}
              onClick={() => onNavigate('ocr-review')}
              className="w-full p-3 rounded-xl shadow-sm flex items-center gap-3"
              style={{ backgroundColor: '#FFFFFF' }}
            >
              <img
                src={receipt.img}
                alt={receipt.store}
                className="w-16 h-16 object-cover rounded-lg"
              />
              <div className="flex-1 text-left">
                <p className="font-semibold" style={{ color: '#0F172A' }}>{receipt.store}</p>
                <p className="text-sm" style={{ color: '#64748B' }}>{receipt.date}</p>
              </div>
              <div className="text-right">
                <p className="font-bold mb-1" style={{ color: '#0F172A' }}>{receipt.amount}</p>
                <span
                  className="text-xs px-2 py-1 rounded-full"
                  style={{
                    backgroundColor: receipt.status === 'Processed' ? '#DBEAFE' : '#FEF3C7',
                    color: receipt.status === 'Processed' ? '#2563EB' : '#F59E0B'
                  }}
                >
                  {receipt.status}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
