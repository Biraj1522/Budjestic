interface BottomNavProps {
  activeScreen: string;
  onNavigate: (screen: string) => void;
}

export default function BottomNav({ activeScreen, onNavigate }: BottomNavProps) {
  const isActive = (screen: string) => activeScreen === screen;

  return (
    <div className="fixed bottom-0 left-0 right-0 border-t px-6 py-3 max-w-md mx-auto" style={{ backgroundColor: '#FFFFFF', borderColor: '#CBD5E1' }}>
      <div className="flex items-center justify-around">
        <button
          onClick={() => onNavigate('home')}
          className="flex flex-col items-center gap-1"
        >
          <div className={`text-2xl ${isActive('home') ? 'opacity-100' : 'opacity-40'}`}>🏠</div>
          <span
            className={`text-xs font-medium`}
            style={{ color: isActive('home') ? '#2563EB' : '#64748B' }}
          >
            Home
          </span>
        </button>

        <button
          onClick={() => onNavigate('receipts')}
          className="flex flex-col items-center gap-1"
        >
          <div className={`text-2xl ${isActive('receipts') ? 'opacity-100' : 'opacity-40'}`}>🧾</div>
          <span
            className={`text-xs font-medium`}
            style={{ color: isActive('receipts') ? '#2563EB' : '#64748B' }}
          >
            Receipts
          </span>
        </button>

        <button
          onClick={() => onNavigate('expenses')}
          className="flex flex-col items-center gap-1"
        >
          <div className={`text-2xl ${isActive('expenses') ? 'opacity-100' : 'opacity-40'}`}>💰</div>
          <span
            className={`text-xs font-medium`}
            style={{ color: isActive('expenses') ? '#2563EB' : '#64748B' }}
          >
            Expenses
          </span>
        </button>

        <button
          onClick={() => onNavigate('insights')}
          className="flex flex-col items-center gap-1"
        >
          <div className={`text-2xl ${isActive('insights') ? 'opacity-100' : 'opacity-40'}`}>📊</div>
          <span
            className={`text-xs font-medium`}
            style={{ color: isActive('insights') ? '#2563EB' : '#64748B' }}
          >
            Insights
          </span>
        </button>

        <button
          onClick={() => onNavigate('profile')}
          className="flex flex-col items-center gap-1"
        >
          <div className={`text-2xl ${isActive('profile') ? 'opacity-100' : 'opacity-40'}`}>👤</div>
          <span
            className={`text-xs font-medium`}
            style={{ color: isActive('profile') ? '#2563EB' : '#64748B' }}
          >
            Profile
          </span>
        </button>
      </div>
    </div>
  );
}
