interface ExpenseScreenProps {
  onNavigate: (screen: string) => void;
}

export default function ExpenseScreen({ onNavigate }: ExpenseScreenProps) {
  const expenses = [
    { id: 1, name: 'SuperMart', category: 'Groceries', amount: '45.20', date: 'May 6' },
    { id: 2, name: 'Coffee Shop', category: 'Food & Dining', amount: '8.50', date: 'May 6' },
    { id: 3, name: 'Gas Station', category: 'Transport', amount: '60.00', date: 'May 5' },
    { id: 4, name: 'Fresh Grocery', category: 'Groceries', amount: '89.50', date: 'May 5' },
    { id: 5, name: 'Netflix Subscription', category: 'Entertainment', amount: '15.99', date: 'May 5' },
    { id: 6, name: 'Restaurant Dinner', category: 'Food & Dining', amount: '78.30', date: 'May 4' },
    { id: 7, name: 'Uber Ride', category: 'Transport', amount: '22.50', date: 'May 4' },
    { id: 8, name: 'Corner Store', category: 'Groceries', amount: '67.80', date: 'May 4' },
    { id: 9, name: 'Pharmacy', category: 'Utilities', amount: '34.20', date: 'May 3' },
    { id: 10, name: 'City Supermarket', category: 'Groceries', amount: '124.30', date: 'May 3' },
    { id: 11, name: 'Coffee Morning', category: 'Food & Dining', amount: '6.75', date: 'May 3' },
    { id: 12, name: 'Movie Tickets', category: 'Entertainment', amount: '32.00', date: 'May 2' },
    { id: 13, name: 'Organic Market', category: 'Groceries', amount: '53.90', date: 'May 2' },
    { id: 14, name: 'Gas Station', category: 'Transport', amount: '55.00', date: 'May 2' },
    { id: 15, name: 'Lunch Takeout', category: 'Food & Dining', amount: '18.90', date: 'May 1' },
    { id: 16, name: 'Daily Mart', category: 'Groceries', amount: '28.45', date: 'May 1' },
    { id: 17, name: 'Electric Bill', category: 'Utilities', amount: '125.00', date: 'May 1' },
    { id: 18, name: 'Food Plaza', category: 'Groceries', amount: '95.60', date: 'Apr 30' },
    { id: 19, name: 'Spotify Premium', category: 'Entertainment', amount: '10.99', date: 'Apr 30' },
    { id: 20, name: 'Express Grocery', category: 'Groceries', amount: '41.25', date: 'Apr 29' },
  ];

  return (
    <div className="h-full overflow-y-auto pb-20" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-4" style={{ color: '#0F172A' }}>Expense Tracking</h2>

        <div className="rounded-xl shadow-sm p-3 mb-4 flex items-center gap-2" style={{ backgroundColor: '#FFFFFF' }}>
          <span style={{ color: '#64748B' }}>🔍</span>
          <input
            type="text"
            placeholder="Search transactions..."
            className="flex-1 outline-none"
            style={{ color: '#0F172A', backgroundColor: 'transparent' }}
          />
          <button className="px-3 py-1 rounded-lg" style={{ backgroundColor: '#EFF6FF', color: '#2563EB' }}>
            Filter
          </button>
        </div>

        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          <button className="px-4 py-2 text-white rounded-full whitespace-nowrap text-sm font-semibold" style={{ backgroundColor: '#2563EB' }}>
            All
          </button>
          <button className="px-4 py-2 rounded-full whitespace-nowrap text-sm font-semibold" style={{ backgroundColor: '#FFFFFF', color: '#0F172A' }}>
            Groceries
          </button>
          <button className="px-4 py-2 rounded-full whitespace-nowrap text-sm font-semibold" style={{ backgroundColor: '#FFFFFF', color: '#0F172A' }}>
            Transport
          </button>
          <button className="px-4 py-2 rounded-full whitespace-nowrap text-sm font-semibold" style={{ backgroundColor: '#FFFFFF', color: '#0F172A' }}>
            Shopping
          </button>
        </div>

        <div className="space-y-3">
          {expenses.map((expense) => (
            <div key={expense.id} className="p-4 rounded-xl shadow-sm flex items-center justify-between" style={{ backgroundColor: '#FFFFFF' }}>
              <div>
                <p className="font-semibold" style={{ color: '#0F172A' }}>{expense.name}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs px-2 py-1 rounded-full" style={{ backgroundColor: '#DBEAFE', color: '#2563EB' }}>
                    {expense.category}
                  </span>
                  <span className="text-sm" style={{ color: '#64748B' }}>• {expense.date}</span>
                </div>
              </div>
              <p className="font-bold" style={{ color: '#DC2626' }}>-${expense.amount}</p>
            </div>
          ))}
        </div>

        <button
          onClick={() => onNavigate('add-expense')}
          className="fixed bottom-24 right-6 w-14 h-14 rounded-full shadow-lg flex items-center justify-center text-white text-2xl"
          style={{ backgroundColor: '#2563EB' }}
        >
          +
        </button>
      </div>
    </div>
  );
}
