interface PredictionScreenProps {
  onNavigate: (screen: string) => void;
}

export default function PredictionScreen({ onNavigate }: PredictionScreenProps) {
  const items = [
    { id: 1, item: 'Milk', lastPurchased: 'May 3, 2026', daysLeft: 2, confidence: 'High' },
    { id: 2, item: 'Bread', lastPurchased: 'May 2, 2026', daysLeft: 3, confidence: 'High' },
    { id: 3, item: 'Rice', lastPurchased: 'Apr 28, 2026', daysLeft: 5, confidence: 'Medium' },
    { id: 4, item: 'Eggs', lastPurchased: 'May 1, 2026', daysLeft: 4, confidence: 'High' }
  ];

  const budgets = [
    { name: 'Grocery Budget', current: 847, total: 900, daysLeft: 24, trend: 'On track' },
    { name: 'Entertainment', current: 310, total: 350, daysLeft: 24, trend: 'Good pace' },
    { name: 'Transport Budget', current: 520, total: 600, daysLeft: 24, trend: 'Under budget' },
    { name: 'Food & Dining', current: 245, total: 300, daysLeft: 24, trend: 'Watch closely' }
  ];

  return (
    <div className="h-full overflow-y-auto pb-20" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="p-6">
        <button onClick={() => onNavigate('insights')} className="mb-4" style={{ color: '#2563EB' }}>
          ← Back
        </button>
        <h2 className="text-2xl font-bold mb-2" style={{ color: '#0F172A' }}>Predictions</h2>
        <p className="mb-6" style={{ color: '#64748B' }}>AI-powered predictions for your spending</p>

        <div className="mb-3">
          <h3 className="font-semibold" style={{ color: '#0F172A' }}>Items Likely to Run Out</h3>
        </div>

        <div className="space-y-3 mb-6">
          {items.map((item) => (
            <div key={item.id} className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FFFFFF' }}>
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="font-semibold mb-1" style={{ color: '#0F172A' }}>{item.item}</p>
                  <p className="text-sm mb-1" style={{ color: '#64748B' }}>Last purchased: {item.lastPurchased}</p>
                  <p className="text-sm" style={{ color: '#64748B' }}>Estimated days left: {item.daysLeft}</p>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  item.daysLeft <= 2 ? 'bg-red-100 text-red-600' :
                  item.daysLeft <= 4 ? 'bg-yellow-100 text-yellow-600' :
                  'bg-blue-100 text-blue-600'
                }`}>
                  {item.confidence} confidence
                </span>
              </div>
              <button className="w-full py-2 rounded-lg text-sm font-semibold" style={{ backgroundColor: '#EFF6FF', color: '#2563EB' }}>
                Set Reminder
              </button>
            </div>
          ))}
        </div>

        <div className="mb-3">
          <h3 className="font-semibold" style={{ color: '#0F172A' }}>Budget Predictions</h3>
        </div>

        <div className="space-y-3 mb-6">
          {budgets.map((budget, index) => (
            <div key={index} className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FFFFFF' }}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <p className="font-semibold mb-1" style={{ color: '#0F172A' }}>{budget.name}</p>
                  <p className="text-sm mb-1" style={{ color: '#64748B' }}>${budget.current} / ${budget.total} • {budget.daysLeft} days left</p>
                  <p className="text-xs" style={{ color: '#64748B' }}>{budget.trend}</p>
                </div>
                {budget.current / budget.total > 0.8 && (
                  <span className="text-xl">⚠️</span>
                )}
              </div>
              <div className="h-2 rounded-full overflow-hidden" style={{ backgroundColor: '#EFF6FF' }}>
                <div
                  className="h-full"
                  style={{
                    width: `${(budget.current / budget.total) * 100}%`,
                    backgroundColor: budget.current / budget.total > 0.8 ? '#F59E0B' : '#2563EB'
                  }}
                ></div>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#DBEAFE' }}>
          <p className="text-sm font-semibold mb-1" style={{ color: '#2563EB' }}>💡 Recommendation</p>
          <p className="text-sm" style={{ color: '#0F172A' }}>Adjust grocery budget by $20 next week</p>
        </div>
      </div>
    </div>
  );
}
