interface LoginScreenProps {
  onNavigate: (screen: string) => void;
}

export default function LoginScreen({ onNavigate }: LoginScreenProps) {
  return (
    <div className="h-full flex flex-col p-6" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="flex-1 flex flex-col justify-center">
        <h1 className="text-3xl font-bold mb-2" style={{ color: '#0F172A' }}>Welcome Back</h1>
        <p className="mb-8" style={{ color: '#64748B' }}>Login to continue managing your budget</p>

        <div className="space-y-4 mb-6">
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: '#0F172A' }}>Email</label>
            <input
              type="email"
              placeholder="Enter your email"
              className="w-full px-4 py-3 rounded-xl border outline-none"
              style={{ backgroundColor: '#FFFFFF', borderColor: '#CBD5E1', color: '#0F172A' }}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: '#0F172A' }}>Password</label>
            <input
              type="password"
              placeholder="Enter your password"
              className="w-full px-4 py-3 rounded-xl border outline-none"
              style={{ backgroundColor: '#FFFFFF', borderColor: '#CBD5E1', color: '#0F172A' }}
            />
          </div>
        </div>

        <button className="text-sm mb-6" style={{ color: '#2563EB' }}>Forgot password?</button>

        <button
          onClick={() => onNavigate('home')}
          className="w-full text-white py-4 rounded-xl font-semibold mb-4"
          style={{ backgroundColor: '#2563EB' }}
        >
          Login
        </button>

        <p className="text-center" style={{ color: '#64748B' }}>
          Don't have an account?{' '}
          <button onClick={() => onNavigate('signup')} className="font-semibold" style={{ color: '#2563EB' }}>
            Create account
          </button>
        </p>
      </div>
    </div>
  );
}
