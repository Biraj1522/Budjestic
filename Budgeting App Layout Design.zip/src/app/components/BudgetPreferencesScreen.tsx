interface BudgetPreferencesScreenProps {
  onNavigate: (screen: string) => void;
}

export default function BudgetPreferencesScreen({ onNavigate }: BudgetPreferencesScreenProps) {
  const categories = [
    { name: 'Groceries', amount: 900 },
    { name: 'Transport', amount: 600 },
    { name: 'Entertainment', amount: 350 },
    { name: 'Utilities', amount: 450 },
    { name: 'Other', amount: 200 }
  ];

  return (
    <div className="h-full overflow-y-auto p-6" style={{ backgroundColor: '#F8FAFC' }}>
      <button onClick={() => onNavigate('profile')} className="mb-4" style={{ color: '#2563EB' }}>
        ← Back
      </button>

      <h2 className="text-2xl font-bold mb-6" style={{ color: '#0F172A' }}>Budget Preferences</h2>

      <div className="mb-6">
        <label className="block text-sm font-medium mb-2" style={{ color: '#0F172A' }}>Monthly Budget</label>
        <div className="relative">
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xl" style={{ color: '#64748B' }}>$</span>
          <input
            type="number"
            value="3500"
            className="w-full pl-10 pr-4 py-3 rounded-xl shadow-sm outline-none"
            style={{ backgroundColor: '#FFFFFF', color: '#0F172A' }}
          />
        </div>
        <p className="text-xs mt-2" style={{ color: '#64748B' }}>Your current spending is $2,847.50 this month</p>
      </div>

      <div className="mb-3">
        <h3 className="font-semibold" style={{ color: '#0F172A' }}>Category Budgets</h3>
      </div>

      <div className="space-y-3 mb-6">
        {categories.map((category) => (
          <div key={category.name} className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FFFFFF' }}>
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium" style={{ color: '#0F172A' }}>{category.name}</span>
              <input
                type="number"
                value={category.amount}
                className="w-24 px-3 py-2 rounded-lg text-right outline-none"
                style={{ backgroundColor: '#EFF6FF', color: '#0F172A' }}
              />
            </div>
          </div>
        ))}
      </div>

      <div className="p-4 rounded-xl shadow-sm mb-6 flex items-center justify-between" style={{ backgroundColor: '#FFFFFF' }}>
        <div>
          <p className="font-medium mb-1" style={{ color: '#0F172A' }}>Smart Budget Alerts</p>
          <p className="text-sm" style={{ color: '#64748B' }}>Get notified when approaching budget limits</p>
        </div>
        <div className="w-12 h-6 rounded-full p-1 flex items-center" style={{ backgroundColor: '#2563EB' }}>
          <div className="w-4 h-4 bg-white rounded-full ml-auto"></div>
        </div>
      </div>

      <button className="w-full py-4 rounded-xl font-semibold text-white" style={{ backgroundColor: '#2563EB' }}>
        Save Changes
      </button>
    </div>
  );
}
