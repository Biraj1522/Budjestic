interface ReportsScreenProps {
  onNavigate: (screen: string) => void;
}

export default function ReportsScreen({ onNavigate }: ReportsScreenProps) {
  return (
    <div className="h-full overflow-y-auto pb-20" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="p-6">
        <button onClick={() => onNavigate('home')} className="mb-4" style={{ color: '#2563EB' }}>
          ← Back
        </button>

        <h2 className="text-2xl font-bold mb-6" style={{ color: '#0F172A' }}>Cash Flow / Reports</h2>

        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FFFFFF' }}>
            <p className="text-sm mb-1" style={{ color: '#64748B' }}>Total Income</p>
            <p className="text-xl font-bold" style={{ color: '#16A34A' }}>$4,200</p>
            <p className="text-xs mt-1" style={{ color: '#64748B' }}>+5% vs last month</p>
          </div>
          <div className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FFFFFF' }}>
            <p className="text-sm mb-1" style={{ color: '#64748B' }}>Total Expenses</p>
            <p className="text-xl font-bold" style={{ color: '#DC2626' }}>$2,847.50</p>
            <p className="text-xs mt-1" style={{ color: '#64748B' }}>-8% vs last month</p>
          </div>
        </div>

        <div className="p-5 rounded-xl shadow-sm mb-6" style={{ backgroundColor: '#DCFCE7' }}>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm mb-1" style={{ color: '#64748B' }}>Net Savings This Month</p>
              <p className="text-2xl font-bold" style={{ color: '#16A34A' }}>$1,352.50</p>
            </div>
            <span className="text-3xl">💰</span>
          </div>
        </div>

        <div className="p-5 rounded-xl shadow-sm mb-6" style={{ backgroundColor: '#FFFFFF' }}>
          <p className="text-sm font-semibold mb-4" style={{ color: '#0F172A' }}>Monthly Cash Flow Trend</p>
          <div className="h-48 rounded-lg p-4 relative" style={{ backgroundColor: '#EFF6FF' }}>
            {/* Y-axis labels */}
            <div className="absolute left-1 top-2 bottom-6 flex flex-col justify-between text-xs" style={{ color: '#64748B' }}>
              <span>$3K</span>
              <span>$2K</span>
              <span>$1K</span>
              <span>$0</span>
            </div>

            {/* Bars */}
            <div className="h-full flex items-end justify-around ml-8 gap-1">
              {[
                { month: 'Jan', income: 4000, expense: 2950, net: 1050 },
                { month: 'Feb', income: 4100, expense: 3100, net: 1000 },
                { month: 'Mar', income: 4000, expense: 2800, net: 1200 },
                { month: 'Apr', income: 4300, expense: 3050, net: 1250 },
                { month: 'May', income: 4200, expense: 2847, net: 1353 }
              ].map((item, i) => (
                <div key={item.month} className="flex flex-col items-center gap-1 flex-1">
                  <div className="w-full flex gap-1 justify-center items-end h-full">
                    {/* Income bar */}
                    <div
                      className="w-4 rounded-t"
                      style={{
                        height: `${(item.income / 3000) * 100}%`,
                        backgroundColor: '#16A34A'
                      }}
                    ></div>
                    {/* Expense bar */}
                    <div
                      className="w-4 rounded-t"
                      style={{
                        height: `${(item.expense / 3000) * 100}%`,
                        backgroundColor: '#DC2626'
                      }}
                    ></div>
                  </div>
                  <span className="text-xs" style={{ color: '#64748B' }}>{item.month}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-center gap-4 mt-3">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded" style={{ backgroundColor: '#16A34A' }}></div>
              <span className="text-xs" style={{ color: '#64748B' }}>Income</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded" style={{ backgroundColor: '#DC2626' }}></div>
              <span className="text-xs" style={{ color: '#64748B' }}>Expenses</span>
            </div>
          </div>
          <div className="mt-3 p-3 rounded-lg" style={{ backgroundColor: '#DCFCE7' }}>
            <p className="text-xs text-center" style={{ color: '#16A34A' }}>
              📈 Your savings increased by 28% compared to last month!
            </p>
          </div>
        </div>

        <div className="p-5 rounded-xl shadow-sm mb-4" style={{ backgroundColor: '#FFFFFF' }}>
          <p className="text-sm font-semibold mb-4" style={{ color: '#0F172A' }}>Category Spending Breakdown</p>
          <div className="space-y-3">
            {[
              { name: 'Groceries', amount: '$847', percent: 35, color: '#2563EB' },
              { name: 'Transport', amount: '$520', percent: 25, color: '#16A34A' },
              { name: 'Food & Dining', amount: '$430', percent: 20, color: '#F59E0B' },
              { name: 'Entertainment', amount: '$310', percent: 15, color: '#8B5CF6' },
              { name: 'Other', amount: '$120', percent: 5, color: '#64748B' }
            ].map((cat) => (
              <div key={cat.name}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm" style={{ color: '#0F172A' }}>{cat.name}</span>
                  <span className="text-sm font-semibold" style={{ color: '#0F172A' }}>{cat.amount}</span>
                </div>
                <div className="h-2 rounded-full overflow-hidden" style={{ backgroundColor: '#EFF6FF' }}>
                  <div className="h-full" style={{ width: `${cat.percent}%`, backgroundColor: cat.color }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FFFFFF' }}>
            <p className="text-sm mb-1" style={{ color: '#64748B' }}>Highest Spending</p>
            <p className="font-bold" style={{ color: '#0F172A' }}>Groceries</p>
            <p className="text-xs mt-1" style={{ color: '#64748B' }}>$847.20</p>
          </div>
          <div className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FFFFFF' }}>
            <p className="text-sm mb-1" style={{ color: '#64748B' }}>Avg Daily Spending</p>
            <p className="font-bold" style={{ color: '#0F172A' }}>$94.92</p>
            <p className="text-xs mt-1" style={{ color: '#64748B' }}>30 days tracked</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FFFFFF' }}>
            <p className="text-sm mb-1" style={{ color: '#64748B' }}>Total Transactions</p>
            <p className="font-bold" style={{ color: '#0F172A' }}>87</p>
            <p className="text-xs mt-1" style={{ color: '#64748B' }}>This month</p>
          </div>
          <div className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FFFFFF' }}>
            <p className="text-sm mb-1" style={{ color: '#64748B' }}>Savings Rate</p>
            <p className="font-bold" style={{ color: '#16A34A' }}>32%</p>
            <p className="text-xs mt-1" style={{ color: '#64748B' }}>Of total income</p>
          </div>
        </div>

        <div className="p-4 rounded-xl shadow-sm mb-4" style={{ backgroundColor: '#DBEAFE' }}>
          <p className="text-sm font-semibold mb-2" style={{ color: '#0F172A' }}>💡 Financial Health Score</p>
          <div className="flex items-center gap-3">
            <div className="flex-1">
              <div className="h-3 rounded-full overflow-hidden" style={{ backgroundColor: '#EFF6FF' }}>
                <div className="h-full" style={{ width: '78%', backgroundColor: '#16A34A' }}></div>
              </div>
            </div>
            <span className="font-bold" style={{ color: '#16A34A' }}>78/100</span>
          </div>
          <p className="text-xs mt-2" style={{ color: '#64748B' }}>Great job! You're managing your finances well.</p>
        </div>

        <button className="w-full py-3 rounded-xl font-semibold border" style={{ backgroundColor: '#FFFFFF', color: '#2563EB', borderColor: '#CBD5E1' }}>
          📥 Export Summary
        </button>
      </div>
    </div>
  );
}
