interface InsightsScreenProps {
  onNavigate: (screen: string) => void;
}

export default function InsightsScreen({ onNavigate }: InsightsScreenProps) {
  const insights = [
    { text: 'You spent more on groceries this week', icon: '📈', color: '#F59E0B' },
    { text: 'Transport costs are stable compared to last month', icon: '✅', color: '#16A34A' },
    { text: 'Entertainment spending is close to the monthly limit', icon: '⚠️', color: '#DC2626' },
    { text: 'Coffee purchases increased by 25% this week', icon: '☕', color: '#F59E0B' },
    { text: 'You saved $45 by cooking at home more often', icon: '🎉', color: '#16A34A' },
    { text: 'Subscription services total $26.98/month', icon: '📱', color: '#2563EB' }
  ];

  return (
    <div className="h-full overflow-y-auto pb-20" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold" style={{ color: '#0F172A' }}>Spending Insights</h2>
          <button
            onClick={() => onNavigate('predictions')}
            className="px-4 py-2 rounded-lg text-sm font-semibold"
            style={{ backgroundColor: '#DBEAFE', color: '#2563EB' }}
          >
            Predictions →
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FFFFFF' }}>
            <p className="text-sm mb-2" style={{ color: '#64748B' }}>Top Category</p>
            <p className="text-lg font-bold mb-1" style={{ color: '#0F172A' }}>Groceries</p>
            <p className="text-xs" style={{ color: '#64748B' }}>$847.20</p>
          </div>

          <div className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FFFFFF' }}>
            <p className="text-sm mb-2" style={{ color: '#64748B' }}>Daily Average</p>
            <p className="text-lg font-bold mb-1" style={{ color: '#2563EB' }}>$94.92</p>
            <p className="text-xs" style={{ color: '#64748B' }}>Last 30 days</p>
          </div>
        </div>

        <div className="p-5 rounded-xl shadow-sm mb-4" style={{ backgroundColor: '#FFFFFF' }}>
          <p className="text-sm font-semibold mb-4" style={{ color: '#0F172A' }}>Spending by Category</p>
          <div className="space-y-3">
            {[
              { name: 'Groceries', percent: 35, color: '#2563EB' },
              { name: 'Transport', percent: 25, color: '#16A34A' },
              { name: 'Food & Dining', percent: 20, color: '#F59E0B' },
              { name: 'Entertainment', percent: 15, color: '#8B5CF6' },
              { name: 'Other', percent: 5, color: '#64748B' }
            ].map((cat) => (
              <div key={cat.name}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm" style={{ color: '#0F172A' }}>{cat.name}</span>
                  <span className="text-sm font-semibold" style={{ color: '#0F172A' }}>{cat.percent}%</span>
                </div>
                <div className="h-2 rounded-full overflow-hidden" style={{ backgroundColor: '#EFF6FF' }}>
                  <div className="h-full" style={{ width: `${cat.percent}%`, backgroundColor: cat.color }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-5 rounded-xl shadow-sm mb-4" style={{ backgroundColor: '#FFFFFF' }}>
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-semibold" style={{ color: '#0F172A' }}>Spending Trend Over Time</p>
            <select className="text-xs px-2 py-1 rounded-lg outline-none" style={{ backgroundColor: '#EFF6FF', color: '#2563EB' }}>
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
              <option>This Month</option>
            </select>
          </div>
          <div className="h-40 rounded-lg p-4 relative" style={{ backgroundColor: '#EFF6FF' }}>
            {/* Y-axis labels */}
            <div className="absolute left-1 top-2 bottom-6 flex flex-col justify-between text-xs" style={{ color: '#64748B' }}>
              <span>$200</span>
              <span>$150</span>
              <span>$100</span>
              <span>$50</span>
              <span>$0</span>
            </div>

            {/* Bars */}
            <div className="h-full flex items-end justify-around ml-8">
              {[
                { day: 'Mon', amount: 125, label: '$125' },
                { day: 'Tue', amount: 95, label: '$95' },
                { day: 'Wed', amount: 160, label: '$160' },
                { day: 'Thu', amount: 78, label: '$78' },
                { day: 'Fri', amount: 145, label: '$145' },
                { day: 'Sat', amount: 185, label: '$185' },
                { day: 'Sun', amount: 110, label: '$110' }
              ].map((item, i) => (
                <div key={item.day} className="flex flex-col items-center gap-1 flex-1 group">
                  <div className="relative w-full flex justify-center">
                    <div
                      className="w-8 rounded-t transition-all group-hover:opacity-80"
                      style={{
                        height: `${(item.amount / 200) * 100}%`,
                        backgroundColor: item.amount > 150 ? '#DC2626' : item.amount > 100 ? '#F59E0B' : '#2563EB'
                      }}
                    >
                      <div className="absolute -top-5 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-xs font-semibold px-2 py-1 rounded" style={{ backgroundColor: '#0F172A', color: '#FFFFFF' }}>
                          {item.label}
                        </span>
                      </div>
                    </div>
                  </div>
                  <span className="text-xs mt-1" style={{ color: '#64748B' }}>{item.day}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-center gap-4 mt-3">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded" style={{ backgroundColor: '#2563EB' }}></div>
              <span className="text-xs" style={{ color: '#64748B' }}>Low ($0-100)</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded" style={{ backgroundColor: '#F59E0B' }}></div>
              <span className="text-xs" style={{ color: '#64748B' }}>Medium ($100-150)</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded" style={{ backgroundColor: '#DC2626' }}></div>
              <span className="text-xs" style={{ color: '#64748B' }}>High ($150+)</span>
            </div>
          </div>
        </div>

        <div className="mb-3">
          <h3 className="font-semibold" style={{ color: '#0F172A' }}>AI Insights</h3>
        </div>

        <div className="space-y-3">
          {insights.map((insight, index) => (
            <div key={index} className="p-4 rounded-xl shadow-sm flex items-start gap-3" style={{ backgroundColor: '#FFFFFF' }}>
              <span className="text-2xl">{insight.icon}</span>
              <p style={{ color: '#0F172A' }}>{insight.text}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
