interface OnboardingScreenProps {
  onNavigate: (screen: string) => void;
}

export default function OnboardingScreen({ onNavigate }: OnboardingScreenProps) {
  return (
    <div className="h-full flex flex-col items-center justify-center p-6" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="flex-1 flex flex-col items-center justify-center">
        <div className="w-24 h-24 rounded-2xl flex items-center justify-center mb-6" style={{ backgroundColor: '#2563EB' }}>
          <span className="text-white text-4xl font-bold">B</span>
        </div>
        <h1 className="text-3xl font-bold mb-3" style={{ color: '#0F172A' }}>Budgestic</h1>
        <p className="text-lg mb-4" style={{ color: '#64748B' }}>Scan receipts, track spending,</p>
        <p className="text-lg mb-6" style={{ color: '#64748B' }}>and budget smarter</p>
        <p className="text-center px-8 mb-8" style={{ color: '#64748B' }}>
          AI-powered budgeting and receipt analysis to help you manage your finances effortlessly
        </p>

        <div className="space-y-3 px-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: '#DBEAFE' }}>
              <span className="text-lg">📸</span>
            </div>
            <div className="flex-1 text-left">
              <p className="font-semibold text-sm" style={{ color: '#0F172A' }}>OCR Receipt Scanning</p>
              <p className="text-xs" style={{ color: '#64748B' }}>Automatically extract expense details</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: '#DBEAFE' }}>
              <span className="text-lg">🤖</span>
            </div>
            <div className="flex-1 text-left">
              <p className="font-semibold text-sm" style={{ color: '#0F172A' }}>AI Predictions</p>
              <p className="text-xs" style={{ color: '#64748B' }}>Know what you'll need before you run out</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: '#DBEAFE' }}>
              <span className="text-lg">📊</span>
            </div>
            <div className="flex-1 text-left">
              <p className="font-semibold text-sm" style={{ color: '#0F172A' }}>Smart Insights</p>
              <p className="text-xs" style={{ color: '#64748B' }}>Get personalized spending analysis</p>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full space-y-3 mb-8">
        <button
          onClick={() => onNavigate('signup')}
          className="w-full text-white py-4 rounded-xl font-semibold"
          style={{ backgroundColor: '#2563EB' }}
        >
          Get Started
        </button>
        <button
          onClick={() => onNavigate('login')}
          className="w-full py-4 rounded-xl font-semibold border"
          style={{ backgroundColor: '#FFFFFF', color: '#2563EB', borderColor: '#CBD5E1' }}
        >
          Login
        </button>
      </div>
    </div>
  );
}
