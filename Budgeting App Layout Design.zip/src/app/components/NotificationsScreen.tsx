interface NotificationsScreenProps {
  onNavigate: (screen: string) => void;
}

export default function NotificationsScreen({ onNavigate }: NotificationsScreenProps) {
  const alerts = [
    { id: 1, icon: '🥛', message: 'Milk is likely to run out in 2 days', time: '2 hours ago', action: 'View' },
    { id: 2, icon: '💰', message: 'Grocery budget is 94% reached', time: '5 hours ago', action: 'Adjust' },
    { id: 3, icon: '🍞', message: 'Bread purchase due in 3 days based on your pattern', time: '8 hours ago', action: 'Remind' },
    { id: 4, icon: '⚠️', message: 'Unusual spending detected in Entertainment category', time: '1 day ago', action: 'Review' },
    { id: 5, icon: '✅', message: 'Receipt from SuperMart processed successfully', time: '1 day ago', action: 'View' },
    { id: 6, icon: '📊', message: 'Weekly spending report is ready', time: '2 days ago', action: 'View' },
    { id: 7, icon: '💡', message: 'You can save $45 by reducing dining out', time: '3 days ago', action: 'Tips' },
    { id: 8, icon: '🎯', message: 'You reached 80% of your savings goal!', time: '4 days ago', action: 'View' }
  ];

  return (
    <div className="h-full overflow-y-auto p-6" style={{ backgroundColor: '#F8FAFC' }}>
      <button onClick={() => onNavigate('home')} className="mb-4" style={{ color: '#2563EB' }}>
        ← Back
      </button>

      <h2 className="text-2xl font-bold mb-6" style={{ color: '#0F172A' }}>Notifications</h2>

      <div className="space-y-3">
        {alerts.map((alert) => (
          <div key={alert.id} className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FFFFFF' }}>
            <div className="flex items-start gap-3">
              <span className="text-2xl">{alert.icon}</span>
              <div className="flex-1">
                <p className="font-medium mb-1" style={{ color: '#0F172A' }}>{alert.message}</p>
                <p className="text-sm mb-3" style={{ color: '#64748B' }}>{alert.time}</p>
                <button className="px-4 py-2 rounded-lg text-sm font-semibold" style={{ backgroundColor: '#DBEAFE', color: '#2563EB' }}>
                  {alert.action}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
