interface SignUpScreenProps {
  onNavigate: (screen: string) => void;
}

export default function SignUpScreen({ onNavigate }: SignUpScreenProps) {
  return (
    <div className="h-full flex flex-col p-6 overflow-y-auto" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="flex-1 flex flex-col justify-center py-8">
        <h1 className="text-3xl font-bold mb-2" style={{ color: '#0F172A' }}>Create Account</h1>
        <p className="mb-8" style={{ color: '#64748B' }}>Sign up to start managing your budget</p>

        <div className="space-y-4 mb-6">
          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: '#0F172A' }}>Full Name</label>
            <input
              type="text"
              placeholder="Enter your full name"
              className="w-full px-4 py-3 rounded-xl border outline-none"
              style={{ backgroundColor: '#FFFFFF', borderColor: '#CBD5E1', color: '#0F172A' }}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: '#0F172A' }}>Email</label>
            <input
              type="email"
              placeholder="Enter your email"
              className="w-full px-4 py-3 rounded-xl border outline-none"
              style={{ backgroundColor: '#FFFFFF', borderColor: '#CBD5E1', color: '#0F172A' }}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: '#0F172A' }}>Password</label>
            <input
              type="password"
              placeholder="Create a password"
              className="w-full px-4 py-3 rounded-xl border outline-none"
              style={{ backgroundColor: '#FFFFFF', borderColor: '#CBD5E1', color: '#0F172A' }}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2" style={{ color: '#0F172A' }}>Confirm Password</label>
            <input
              type="password"
              placeholder="Confirm your password"
              className="w-full px-4 py-3 rounded-xl border outline-none"
              style={{ backgroundColor: '#FFFFFF', borderColor: '#CBD5E1', color: '#0F172A' }}
            />
          </div>
        </div>

        <button
          onClick={() => onNavigate('home')}
          className="w-full text-white py-4 rounded-xl font-semibold mb-4"
          style={{ backgroundColor: '#2563EB' }}
        >
          Create Account
        </button>

        <p className="text-center" style={{ color: '#64748B' }}>
          Already have an account?{' '}
          <button onClick={() => onNavigate('login')} className="font-semibold" style={{ color: '#2563EB' }}>
            Login
          </button>
        </p>
      </div>
    </div>
  );
}
