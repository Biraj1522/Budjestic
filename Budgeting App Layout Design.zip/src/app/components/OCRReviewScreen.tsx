import { useState } from 'react';

interface OCRReviewScreenProps {
  onNavigate: (screen: string) => void;
}

export default function OCRReviewScreen({ onNavigate }: OCRReviewScreenProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [storeName, setStoreName] = useState('SuperMart');
  const [date, setDate] = useState('2026-05-06');
  const [category, setCategory] = useState('Groceries');
  const [items, setItems] = useState([
    { name: 'Milk 1L', price: '3.50' },
    { name: 'Bread Whole Wheat', price: '2.80' },
    { name: 'Eggs (12 pack)', price: '4.20' },
    { name: 'Tomatoes', price: '5.60' },
    { name: 'Chicken Breast', price: '12.40' },
  ]);

  const total = items.reduce((sum, item) => sum + parseFloat(item.price), 0).toFixed(2);

  const updateItem = (index: number, field: 'name' | 'price', value: string) => {
    const newItems = [...items];
    newItems[index][field] = value;
    setItems(newItems);
  };

  return (
    <div className="h-full overflow-y-auto pb-20" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="p-6">
        <button onClick={() => onNavigate('receipts')} className="mb-4" style={{ color: '#2563EB' }}>
          ← Back
        </button>

        <h2 className="text-2xl font-bold mb-6" style={{ color: '#0F172A' }}>OCR Result Review</h2>

        <div className="p-4 rounded-xl shadow-sm mb-4" style={{ backgroundColor: '#FFFFFF' }}>
          <div className="flex justify-between mb-3">
            <span className="text-sm" style={{ color: '#64748B' }}>Store Name</span>
            {isEditing ? (
              <input
                type="text"
                value={storeName}
                onChange={(e) => setStoreName(e.target.value)}
                className="font-semibold text-right outline-none px-2 py-1 rounded"
                style={{ color: '#0F172A', backgroundColor: '#EFF6FF' }}
              />
            ) : (
              <span className="font-semibold" style={{ color: '#0F172A' }}>{storeName}</span>
            )}
          </div>
          <div className="flex justify-between mb-3">
            <span className="text-sm" style={{ color: '#64748B' }}>Date</span>
            {isEditing ? (
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="font-semibold text-right outline-none px-2 py-1 rounded"
                style={{ color: '#0F172A', backgroundColor: '#EFF6FF' }}
              />
            ) : (
              <span className="font-semibold" style={{ color: '#0F172A' }}>
                {new Date(date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
              </span>
            )}
          </div>
          <div className="flex justify-between">
            <span className="text-sm" style={{ color: '#64748B' }}>Suggested Category</span>
            {isEditing ? (
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="px-3 py-1 rounded-full text-sm font-semibold outline-none"
                style={{ backgroundColor: '#DBEAFE', color: '#2563EB' }}
              >
                <option>Groceries</option>
                <option>Food & Dining</option>
                <option>Transport</option>
                <option>Entertainment</option>
                <option>Utilities</option>
                <option>Other</option>
              </select>
            ) : (
              <span className="px-3 py-1 rounded-full text-sm font-semibold" style={{ backgroundColor: '#DBEAFE', color: '#2563EB' }}>
                {category}
              </span>
            )}
          </div>
        </div>

        <div className="mb-3">
          <h3 className="font-semibold" style={{ color: '#0F172A' }}>Items Purchased</h3>
        </div>

        <div className="p-4 rounded-xl shadow-sm mb-4" style={{ backgroundColor: '#FFFFFF' }}>
          <div className="space-y-3">
            {items.map((item, index) => (
              <div key={index} className="flex justify-between items-center pb-3 border-b last:border-b-0" style={{ borderColor: '#CBD5E1' }}>
                {isEditing ? (
                  <>
                    <input
                      type="text"
                      value={item.name}
                      onChange={(e) => updateItem(index, 'name', e.target.value)}
                      className="flex-1 outline-none px-2 py-1 rounded mr-2"
                      style={{ color: '#0F172A', backgroundColor: '#EFF6FF' }}
                    />
                    <div className="flex items-center gap-1">
                      <span style={{ color: '#64748B' }}>$</span>
                      <input
                        type="number"
                        step="0.01"
                        value={item.price}
                        onChange={(e) => updateItem(index, 'price', e.target.value)}
                        className="w-20 font-semibold text-right outline-none px-2 py-1 rounded"
                        style={{ color: '#0F172A', backgroundColor: '#EFF6FF' }}
                      />
                    </div>
                  </>
                ) : (
                  <>
                    <span style={{ color: '#0F172A' }}>{item.name}</span>
                    <span className="font-semibold" style={{ color: '#0F172A' }}>${item.price}</span>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="p-4 rounded-xl shadow-sm mb-6" style={{ backgroundColor: '#FFFFFF' }}>
          <div className="flex justify-between">
            <span className="font-semibold" style={{ color: '#0F172A' }}>Total Amount</span>
            <span className="text-xl font-bold" style={{ color: '#2563EB' }}>${total}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="py-3 rounded-xl font-semibold border"
            style={{
              backgroundColor: isEditing ? '#2563EB' : '#FFFFFF',
              color: isEditing ? '#FFFFFF' : '#2563EB',
              borderColor: '#CBD5E1'
            }}
          >
            {isEditing ? 'Done Editing' : 'Edit Details'}
          </button>
          <button
            onClick={() => onNavigate('expenses')}
            className="py-3 rounded-xl font-semibold text-white"
            style={{ backgroundColor: '#2563EB' }}
          >
            Save Expense
          </button>
        </div>
      </div>
    </div>
  );
}
