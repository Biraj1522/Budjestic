interface AddExpenseScreenProps {
  onNavigate: (screen: string) => void;
}

export default function AddExpenseScreen({ onNavigate }: AddExpenseScreenProps) {
  return (
    <div className="h-full overflow-y-auto p-6" style={{ backgroundColor: '#F8FAFC' }}>
      <button onClick={() => onNavigate('expenses')} className="mb-4" style={{ color: '#2563EB' }}>
        ← Back
      </button>

      <h2 className="text-2xl font-bold mb-6" style={{ color: '#0F172A' }}>Add Expense</h2>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2" style={{ color: '#0F172A' }}>Amount</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-xl" style={{ color: '#64748B' }}>$</span>
            <input
              type="number"
              placeholder="0.00"
              className="w-full pl-10 pr-4 py-3 rounded-xl shadow-sm outline-none"
              style={{ backgroundColor: '#FFFFFF', color: '#0F172A' }}
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2" style={{ color: '#0F172A' }}>Category</label>
          <select
            className="w-full px-4 py-3 rounded-xl shadow-sm outline-none"
            style={{ backgroundColor: '#FFFFFF', color: '#0F172A' }}
          >
            <option>Select category</option>
            <option>Groceries</option>
            <option>Transport</option>
            <option>Food & Dining</option>
            <option>Entertainment</option>
            <option>Utilities</option>
            <option>Other</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2" style={{ color: '#0F172A' }}>Date</label>
          <input
            type="date"
            className="w-full px-4 py-3 rounded-xl shadow-sm outline-none"
            style={{ backgroundColor: '#FFFFFF', color: '#0F172A' }}
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2" style={{ color: '#0F172A' }}>Payment Method</label>
          <select
            className="w-full px-4 py-3 rounded-xl shadow-sm outline-none"
            style={{ backgroundColor: '#FFFFFF', color: '#0F172A' }}
          >
            <option>Select payment method</option>
            <option>Cash</option>
            <option>Credit Card</option>
            <option>Debit Card</option>
            <option>Digital Wallet</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2" style={{ color: '#0F172A' }}>Notes</label>
          <textarea
            placeholder="Add notes (optional)"
            rows={3}
            className="w-full px-4 py-3 rounded-xl shadow-sm outline-none resize-none"
            style={{ backgroundColor: '#FFFFFF', color: '#0F172A' }}
          />
        </div>

        <button
          onClick={() => onNavigate('expenses')}
          className="w-full py-4 rounded-xl font-semibold text-white mt-6"
          style={{ backgroundColor: '#2563EB' }}
        >
          Save Expense
        </button>
      </div>
    </div>
  );
}
