interface ProfileScreenProps {
  onNavigate: (screen: string) => void;
}

export default function ProfileScreen({ onNavigate }: ProfileScreenProps) {
  return (
    <div className="h-full overflow-y-auto pb-20" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-6" style={{ color: '#0F172A' }}>Profile & Settings</h2>

        <div className="p-5 rounded-xl shadow-sm mb-4 flex items-center gap-4" style={{ backgroundColor: '#FFFFFF' }}>
          <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ backgroundColor: '#2563EB' }}>
            <span className="text-white text-2xl font-bold">U</span>
          </div>
          <div className="flex-1">
            <p className="font-bold" style={{ color: '#0F172A' }}>User Name</p>
            <p className="text-sm" style={{ color: '#64748B' }}>user@email.com</p>
            <p className="text-xs mt-1" style={{ color: '#64748B' }}>Member since May 2026</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="p-3 rounded-xl shadow-sm text-center" style={{ backgroundColor: '#FFFFFF' }}>
            <p className="text-xl font-bold" style={{ color: '#2563EB' }}>87</p>
            <p className="text-xs" style={{ color: '#64748B' }}>Transactions</p>
          </div>
          <div className="p-3 rounded-xl shadow-sm text-center" style={{ backgroundColor: '#FFFFFF' }}>
            <p className="text-xl font-bold" style={{ color: '#16A34A' }}>$1,352</p>
            <p className="text-xs" style={{ color: '#64748B' }}>Saved</p>
          </div>
          <div className="p-3 rounded-xl shadow-sm text-center" style={{ backgroundColor: '#FFFFFF' }}>
            <p className="text-xl font-bold" style={{ color: '#F59E0B' }}>10</p>
            <p className="text-xs" style={{ color: '#64748B' }}>Receipts</p>
          </div>
        </div>

        <div className="mb-3">
          <h3 className="font-semibold" style={{ color: '#0F172A' }}>Settings</h3>
        </div>

        <div className="rounded-xl shadow-sm overflow-hidden mb-6" style={{ backgroundColor: '#FFFFFF' }}>
          <button className="w-full p-4 flex items-center justify-between border-b" style={{ borderColor: '#CBD5E1' }}>
            <span style={{ color: '#0F172A' }}>Account Settings</span>
            <span style={{ color: '#64748B' }}>→</span>
          </button>
          <button
            onClick={() => onNavigate('budget-preferences')}
            className="w-full p-4 flex items-center justify-between border-b"
            style={{ borderColor: '#CBD5E1' }}
          >
            <span style={{ color: '#0F172A' }}>Budget Preferences</span>
            <span style={{ color: '#64748B' }}>→</span>
          </button>
          <button
            onClick={() => onNavigate('notifications')}
            className="w-full p-4 flex items-center justify-between border-b"
            style={{ borderColor: '#CBD5E1' }}
          >
            <span style={{ color: '#0F172A' }}>Notifications</span>
            <span style={{ color: '#64748B' }}>→</span>
          </button>
          <button className="w-full p-4 flex items-center justify-between border-b" style={{ borderColor: '#CBD5E1' }}>
            <span style={{ color: '#0F172A' }}>Security & Privacy</span>
            <span style={{ color: '#64748B' }}>→</span>
          </button>
          <button className="w-full p-4 flex items-center justify-between border-b" style={{ borderColor: '#CBD5E1' }}>
            <span style={{ color: '#0F172A' }}>Categories</span>
            <span style={{ color: '#64748B' }}>→</span>
          </button>
          <button className="w-full p-4 flex items-center justify-between border-b" style={{ borderColor: '#CBD5E1' }}>
            <span style={{ color: '#0F172A' }}>Help & Support</span>
            <span style={{ color: '#64748B' }}>→</span>
          </button>
          <button className="w-full p-4 flex items-center justify-between" onClick={() => onNavigate('onboarding')}>
            <span style={{ color: '#0F172A' }}>About</span>
            <span style={{ color: '#64748B' }}>→</span>
          </button>
        </div>

        <button
          onClick={() => onNavigate('onboarding')}
          className="w-full p-4 rounded-xl shadow-sm"
          style={{ backgroundColor: '#FFFFFF', color: '#DC2626' }}
        >
          Logout
        </button>
      </div>
    </div>
  );
}
