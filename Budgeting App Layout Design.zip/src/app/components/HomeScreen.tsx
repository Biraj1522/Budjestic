interface HomeScreenProps {
  onNavigate: (screen: string) => void;
}

export default function HomeScreen({ onNavigate }: HomeScreenProps) {
  return (
    <div className="h-full overflow-y-auto pb-20" style={{ backgroundColor: '#F8FAFC' }}>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold mb-1" style={{ color: '#0F172A' }}>Hello, User</h2>
            <p style={{ color: '#64748B' }}>May 6, 2026 • Tuesday</p>
          </div>
          <button
            onClick={() => onNavigate('notifications')}
            className="w-10 h-10 rounded-full flex items-center justify-center relative"
            style={{ backgroundColor: '#EFF6FF' }}
          >
            <span style={{ color: '#2563EB' }}>🔔</span>
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full" style={{ backgroundColor: '#DC2626' }}></span>
          </button>
        </div>

        <div className="space-y-3 mb-6">
          <div className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FFFFFF' }}>
            <p className="text-sm mb-1" style={{ color: '#64748B' }}>Total Spending</p>
            <p className="text-2xl font-bold" style={{ color: '#0F172A' }}>$2,847.50</p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FFFFFF' }}>
              <p className="text-sm mb-1" style={{ color: '#64748B' }}>Monthly Budget</p>
              <p className="text-xl font-bold" style={{ color: '#0F172A' }}>$3,500</p>
            </div>
            <div className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FFFFFF' }}>
              <p className="text-sm mb-1" style={{ color: '#64748B' }}>Remaining Balance</p>
              <p className="text-xl font-bold" style={{ color: '#16A34A' }}>$652.50</p>
            </div>
          </div>
        </div>

        <div className="p-5 rounded-xl shadow-sm mb-6" style={{ backgroundColor: '#FFFFFF' }}>
          <p className="text-sm font-semibold mb-4" style={{ color: '#0F172A' }}>Cash Flow Overview</p>
          <div className="flex justify-between mb-3">
            <div>
              <p className="text-sm" style={{ color: '#64748B' }}>Income</p>
              <p className="text-lg font-bold" style={{ color: '#16A34A' }}>$4,200</p>
            </div>
            <div className="text-right">
              <p className="text-sm" style={{ color: '#64748B' }}>Expenses</p>
              <p className="text-lg font-bold" style={{ color: '#DC2626' }}>$2,847.50</p>
            </div>
          </div>
        </div>

        <div className="p-5 rounded-xl shadow-sm mb-6" style={{ backgroundColor: '#FFFFFF' }}>
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm font-semibold" style={{ color: '#0F172A' }}>Weekly Spending Overview</p>
            <span className="text-xs px-2 py-1 rounded-full" style={{ backgroundColor: '#DCFCE7', color: '#16A34A' }}>-8% vs last week</span>
          </div>
          <div className="h-40 rounded-lg p-3 relative" style={{ backgroundColor: '#EFF6FF' }}>
            <div className="h-full flex items-end justify-around gap-2">
              {[
                { day: 'Mon', height: 60, amount: '$125' },
                { day: 'Tue', height: 45, amount: '$95' },
                { day: 'Wed', height: 80, amount: '$160' },
                { day: 'Thu', height: 38, amount: '$78' },
                { day: 'Fri', height: 70, amount: '$145' },
                { day: 'Sat', height: 90, amount: '$185' },
                { day: 'Sun', height: 55, amount: '$110' }
              ].map((item, i) => (
                <div key={item.day} className="flex flex-col items-center gap-1 flex-1">
                  <div className="w-full flex justify-center">
                    <div
                      className="w-6 rounded-t"
                      style={{
                        height: `${item.height}%`,
                        backgroundColor: i === new Date().getDay() - 1 ? '#F59E0B' : '#2563EB'
                      }}
                    ></div>
                  </div>
                  <span className="text-xs" style={{ color: '#64748B' }}>{item.day}</span>
                </div>
              ))}
            </div>
          </div>
          <p className="text-xs text-center mt-3" style={{ color: '#64748B' }}>Total this week: $898</p>
        </div>

        <div className="grid grid-cols-3 gap-3 mb-6">
          <button
            onClick={() => onNavigate('receipts')}
            className="text-white p-4 rounded-xl text-center"
            style={{ backgroundColor: '#2563EB' }}
          >
            <div className="text-2xl mb-1">📸</div>
            <p className="text-xs font-semibold">Upload Receipt</p>
          </button>
          <button
            onClick={() => onNavigate('add-expense')}
            className="p-4 rounded-xl text-center shadow-sm"
            style={{ backgroundColor: '#FFFFFF', color: '#0F172A' }}
          >
            <div className="text-2xl mb-1">➕</div>
            <p className="text-xs font-semibold">Add Expense</p>
          </button>
          <button
            onClick={() => onNavigate('reports')}
            className="p-4 rounded-xl text-center shadow-sm"
            style={{ backgroundColor: '#FFFFFF', color: '#0F172A' }}
          >
            <div className="text-2xl mb-1">📊</div>
            <p className="text-xs font-semibold">View Reports</p>
          </button>
        </div>

        <div className="mb-3">
          <h3 className="font-semibold" style={{ color: '#0F172A' }}>AI Recommendations</h3>
        </div>

        <div className="space-y-3 mb-6">
          <div className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#DBEAFE' }}>
            <div className="flex items-start gap-3">
              <span className="text-xl">💡</span>
              <div>
                <p className="font-semibold mb-1" style={{ color: '#0F172A' }}>Save $150 this month</p>
                <p className="text-sm" style={{ color: '#64748B' }}>You're on track! Reduce dining out by 2 meals to hit your savings goal.</p>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#FEF3C7' }}>
            <div className="flex items-start gap-3">
              <span className="text-xl">⚠️</span>
              <div>
                <p className="font-semibold mb-1" style={{ color: '#0F172A' }}>Grocery budget at 94%</p>
                <p className="text-sm" style={{ color: '#64748B' }}>Only $53 left for groceries this month. Consider meal planning.</p>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl shadow-sm" style={{ backgroundColor: '#DCFCE7' }}>
            <div className="flex items-start gap-3">
              <span className="text-xl">✅</span>
              <div>
                <p className="font-semibold mb-1" style={{ color: '#0F172A' }}>Great job on transport!</p>
                <p className="text-sm" style={{ color: '#64748B' }}>You spent 15% less than usual on transport this month.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-3">
          <h3 className="font-semibold" style={{ color: '#0F172A' }}>Recent Transactions</h3>
        </div>

        <div className="space-y-2">
          {[
            { name: 'SuperMart', category: 'Groceries', amount: '45.20', date: 'Today' },
            { name: 'Coffee Shop', category: 'Food & Dining', amount: '8.50', date: 'Today' },
            { name: 'Gas Station', category: 'Transport', amount: '60.00', date: 'Yesterday' },
          ].map((txn, index) => (
            <button
              key={index}
              onClick={() => onNavigate('expenses')}
              className="w-full p-3 rounded-xl shadow-sm flex items-center justify-between"
              style={{ backgroundColor: '#FFFFFF' }}
            >
              <div className="text-left">
                <p className="font-semibold text-sm" style={{ color: '#0F172A' }}>{txn.name}</p>
                <p className="text-xs" style={{ color: '#64748B' }}>{txn.category} • {txn.date}</p>
              </div>
              <p className="font-bold text-sm" style={{ color: '#DC2626' }}>-${txn.amount}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
