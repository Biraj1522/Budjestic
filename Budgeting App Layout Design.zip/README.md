
  # Budgeting App Layout Design

  This is a code bundle for Budgeting App Layout Design. The original project is available at https://www.figma.com/design/YPj2sSpDvQXjqUWR0uUfd8/Budgeting-App-Layout-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  